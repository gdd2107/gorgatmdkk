import './App.css'
import { Routes, Route } from 'react-router-dom'
import HomePage from './Components/HomePage/HomePage'
import AddPage from './Components/AddPage/AddPage'

function App() {

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/add" element={<AddPage />} />
    </Routes>
  )
}

export default App
