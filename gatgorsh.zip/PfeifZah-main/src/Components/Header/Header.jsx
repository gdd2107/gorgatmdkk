import styles from './Header.module.css'
import { Link } from 'react-router-dom'

function Header() {

    return (
        <>
            <header>
                <div className={styles.header}>
                    <div>
                        <Link to="/" style={{ textDecoration: 'none', color: 'inherit' }}>
                            <h1>ПОСТАВЩИК</h1>
                            <p>От завода без посредников</p>
                        </Link>
                    </div>
                    <div className={styles.nav}>
                        <nav>
                            <ul>
                                <li>Доставка</li>
                                <li>Оплата</li>
                                <li>Контакты</li>
                                <li><Link to="/add" style={{ textDecoration: 'none', color: 'inherit' }}>Добавить товар</Link></li>
                            </ul>
                        </nav>
                        <div className={styles.nomer}>8-800-550-01-09</div>
                    </div>
                </div>
            </header>


        </>
    )
}

export default Header