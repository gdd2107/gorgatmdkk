import styles from './Footer.module.css'

function Footer() {

    return (
        <>
            <footer>
                <div className={styles.footerContainer}>
                    <div className={styles.footerColumn}>
                        <h3 className={styles.footerLogo}>ПОСТАВЩИК</h3>
                        <p className={styles.footerPhone}>8 800 00 00 00 3</p>
                        <p className={styles.footerEmail}>artvan@driebr</p>
                    </div>



                    <div className={styles.footerColumn}>
                        <h4 className={styles.footerTitle}>Информация</h4>
                        <ul className={styles.footerList}>
                            <li>Оплата</li>
                            <li>Доставка</li>
                            <li>Политика обработки персональных данных</li>
                            <li>Согласие на обработку персональных данных</li>
                        </ul>
                    </div>


                    <div className={styles.footerColumn2}>
                        <h4 className={styles.footerTitle}>Центральный офис и склад</h4>
                        <p className={styles.footerAddress}>Г Оренбург</p>
                        <p className={styles.footerPhone}>8 800 00 00 00 3</p>
                        <p className={styles.footerSchedule}>Режим работы: Пн-Пт с 9:00 до 18:00, Сб с 9:00 до 14:00</p>
                        <p className={styles.footerSignals}>Региональные сигналы</p>
                    </div>
                </div>
            </footer>
        </>
    )
}

export default Footer