import Header from '../Header/Header'
import Footer from '../Footer/Footer'
import CreateProductForm from './Components/CreateProductForm/CreateProductForm'
import Kartocki from '../HomePage/Components/Kartocki/Kartocki'

function AddPage() {
    return (
        <>
            <Header></Header>
            <CreateProductForm></CreateProductForm>
            <Kartocki></Kartocki>
            <Footer></Footer>
        </>
    )
}

export default AddPage
