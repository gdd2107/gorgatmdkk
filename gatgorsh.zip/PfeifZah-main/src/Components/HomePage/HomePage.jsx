
import Header from '../Header/Header'
import Footer from '../Footer/Footer'
import Tovars from './Components/Kartocki/Kartocki'
import MainSection from './Components/MainSection/MainSection'
import FramerMotionExamples from './Components/FramerMotionExamples/FramerMotionExamples'

function HomePage() {

    return (
        <>
            <Header></Header>
            <MainSection></MainSection>
            <FramerMotionExamples></FramerMotionExamples>
            <Tovars></Tovars>
            <Footer></Footer>
        </>
    )
}

export default HomePage
