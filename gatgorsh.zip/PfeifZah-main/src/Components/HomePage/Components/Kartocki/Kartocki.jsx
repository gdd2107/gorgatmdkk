import ProductKart from '../ProductKart/ProductKart';
import styles from './Kartocki.module.css'
import { useEffect } from 'react';
import { useState } from 'react'
import axios from 'axios';



function Kartocki() {

    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get("https://torguisam.ru/api/product/oksei-all-products");
                setProducts(response.data);

                setLoading(false);
            } catch (err) {
                setError(err.message);
                setLoading(false);
            }
        };
        fetchProducts();
    }, []);

    if (loading) {
        return <div>Загрузка товаров...</div>
    }

    if (error) {
        return <div>Ошибка: {error}</div>
    }
    return (
        <>
            <p className={styles.TovarH}>Популярное</p>
            <div className={styles.TovarCont}>

                {products.map((product) => (
                    <ProductKart key={product.id} product={product} />
                ))}

            </div>
        </>
    )
}

export default Kartocki