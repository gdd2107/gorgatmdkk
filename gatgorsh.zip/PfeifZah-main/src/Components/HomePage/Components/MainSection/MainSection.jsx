import styles from './MainSection.module.css'

function MainSection() {

    return (
        <>
            <main>
                <div className={styles.mainContainer}>
                    <button className={styles.catalogBtn}>
                        КАТАЛОГ
                    </button>
                    <div className={styles.searchContainer}>
                        <input
                            type="text"
                            placeholder="Поиск"
                            className={styles.searchInput}
                        />
                        <button className={styles.searchBtn}>Поиск</button>
                    </div>
                </div>

                <div className={styles.wrapper}>
                    <div className={styles.info}>
                        <h2 className={styles.heading}>Новинка в России</h2>
                        <p className={styles.text }>Север - теплоизоляция для сурового климата</p>
                        <h2 className={styles.text2 }>от 850Р за 3м</h2>
                        <button className={styles.moreBtn}>Подробнее</button>
                    </div>
                </div>
            </main>
        </>
    )
}

export default MainSection