import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";


const FramerMotionExamples = () => {
    const [isVisible, setIsVisible] = useState(true);
    const [selectedItem, setSelectedItem] = useState(null);
    const [count, setCount] = useState(0);
    // Пример 1: Базовая анимация появления
    const fadeInVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: { duration: 0.6, ease: "easeOut" },
        },
    };
    // Пример 2: Анимация при наведении
    const hoverVariants = {
        hover: {
            scale: 1.05,
            rotate: 2,
            boxShadow: "0px 10px 30px rgba(0, 0, 0, 0.2)",
            transition: { type: "spring", stiffness: 300 },
        },
    };
    // Пример 3: Сложная анимация с keyframes
    const complexVariants = {
        animate: {
            x: [0, 100, 0],
            y: [0, -50, 0],
            rotate: [0, 180, 360],
            borderRadius: ["10%", "50%", "10%"],
            transition: {
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse",
            },
        },
    };
    // Пример 4: Stagger animation (поочередная анимация)
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                delayChildren: 0.2,
                staggerChildren: 0.1,
            },
        },
    };
    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: {
            y: 0,
            opacity: 1,
            transition: { type: "spring", stiffness: 100 },
        },
    };
    // Пример 5: Layout animation
    const layoutVariants = {
        expanded: { width: 300, height: 200 },
        collapsed: { width: 100, height: 100 },
    };
    // Пример 6: Gesture-based animation
    const dragVariants = {
        drag: { scale: 1.1, cursor: "grabbing" },
    };
    const items = ["Item 1", "Item 2", "Item 3", "Item 4"];
    return (
        <div className="framer-examples-container">
            <h1>Framer Motion Examples</h1>
            {/* Пример 1: Базовая анимация */}
            <section className="example-section">
                <h2>1. Базовая анимация появления</h2>
                <motion.div
                    className="basic-box"
                    variants={fadeInVariants}
                    initial="hidden"
                    animate="visible"
                >
                    Fade In Animation
                </motion.div>
            </section>
            {/* Пример 2: Hover анимация */}
            <section className="example-section">
                <h2>2. Анимация при наведении</h2>
                <motion.div
                    className="hover-box"
                    variants={hoverVariants}
                    whileHover="hover"
                >
                    Hover me!
                </motion.div>
            </section>
            {/* Пример 3: Сложная анимация */}
            <section className="example-section">
                <h2>3. Сложная анимация (keyframes)</h2>
                <motion.div
                    className="complex-box"
                    variants={complexVariants}
                    animate="animate"
                >
                    Complex
                </motion.div>
            </section>
            {/* Пример 4: Stagger animation */}
            <section className="example-section">
                <h2>4. Поочередная анимация (Stagger)</h2>
                <motion.ul
                    className="stagger-list"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    {items.map((item, index) => (
                        <motion.li
                            key={index}
                            className="stagger-item"
                            variants={itemVariants}
                        >
                            {item}
                        </motion.li>
                    ))}
                </motion.ul>
            </section>
            {/* Пример 5: Layout animation */}
            <section className="example-section">
                <h2>5. Layout анимация</h2>
                <motion.div
                    className="layout-box"
                    layout
                    animate={selectedItem ? "expanded" : "collapsed"}
                    variants={layoutVariants}
                    onClick={() => setSelectedItem(!selectedItem)}
                >
                    <p>Click to expand/collapse</p>
                    {selectedItem && (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                        >
                            <p>Expanded content appears here!</p>
                        </motion.div>
                    )}
                </motion.div>
            </section>
            {/* Пример 6: Drag animation */}
            <section className="example-section">
                <h2>6. Перетаскивание (Drag)</h2>
                <motion.div
                    className="drag-box"
                    drag
                    dragConstraints={{ left: 0, right: 200, top: 0, bottom: 100 }}
                    variants={dragVariants}
                    whileDrag="drag"
                    dragElastic={0.2}
                >
                    Drag me around!
                </motion.div>
            </section>
            {/* Пример 7: AnimatePresence (условная анимация) */}
            <section className="example-section">
                <h2>7. Условная анимация (AnimatePresence)</h2>
                <button className="toggle-btn" onClick={() => setIsVisible(!isVisible)}>
                    Toggle Visibility
                </button>
                <AnimatePresence>
                    {isVisible && (
                        <motion.div
                            className="presence-box"
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            transition={{ duration: 0.3 }}
                        >
                            I can appear and disappear!
                        </motion.div>
                    )}
                </AnimatePresence>
            </section>
            {/* Пример 8: Анимация при клике */}
            <section className="example-section">
                <h2>8. Анимация при клике</h2>
                <motion.button
                    className="click-btn"
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setCount(count + 1)}
                >
                    Clicked {count} times
                </motion.button>
            </section>
            {/* Пример 9: Анимация по скроллу */}
            <section className="example-section">
                <h2>9. Анимация по скроллу</h2>
                <motion.div
                    className="scroll-box"
                    initial={{ opacity: 0, x: -100 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                >
                    Appears when scrolled into view
                </motion.div>
            </section>
            {/* Пример 10: Анимация текста */}
            <section className="example-section">
                <h2>10. Анимация текста</h2>
                <motion.h3
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 1 }}
                >
                    {Array.from("Animated Text").map((char, index) => (
                        <motion.span
                            key={index}
                            initial={{ opacity: 0, y: 50 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{
                                duration: 0.5,
                                delay: index * 0.1,
                                type: "spring",
                            }}
                        >
                            {char === " " ? "\u00A0" : char}
                        </motion.span>
                    ))}
                </motion.h3>
            </section>
        </div>
    );
};
export default FramerMotionExamples;
