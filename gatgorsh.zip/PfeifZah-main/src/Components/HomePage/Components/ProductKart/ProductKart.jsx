import styles from './ProductCard.module.css'
import { motion } from 'framer-motion';

function ProductCard({ product }) {

    if (!product) {
        return null;
    }
    
    const hoverVariants = {
        hover: {
            scale: 1.05,
            rotate: 2,
            boxShadow: "0px 10px 30px rgba(0, 0, 0, 0.2)",
            transition: { type: "spring", stiffness: 300 },
        },
    };
    return (
        <motion.div className={styles.kartocka} variants={hoverVariants}
            whileHover="hover">
            <img className={styles.kartockaImage} src={product.image || product.images?.[0] || ''} alt={product.name} />
            <div className="product-info">
                <span>ID: {product.id}</span>
                <h3 className={styles.kartockaName}>{product.name}</h3>
                <p className={styles.kartockaDescription}>
                    {product.description && product.description.length > 50
                        ? product.description.substring(0, 50) + "..."
                        : product.description || "Описание отсутствует"}
                </p>
            </div>
        </motion.div>

    );
}
export default ProductCard;