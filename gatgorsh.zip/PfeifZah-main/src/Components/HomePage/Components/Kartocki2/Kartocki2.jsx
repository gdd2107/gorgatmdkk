import styles from './Kartocki2.module.css'

function Kartocki2() {

    return (
        <>
            <div>
                <div className={styles.kartockiContainer}>
                    <div className={styles.kartockiHeader}>
                        <h3 className={styles.kartockiHeading}>Теплоизоляция</h3>
                        <button className={styles.kartockiBtn}>СМОТРЕТЬ ВСЕ</button>
                    </div>
                    <div className={styles.kartockiGrid}>
                        <div className={styles.kartocka}>
                            <div className={styles.kartockaImage}>
                                <img src="/img/teplo.webp" alt="" />
                            </div>
                            <div className={styles.kartockaContent}>
                                <p className={styles.kartockaName}>Пенопленекс Кофморт 1185x585x20мм</p>
                                <p className={styles.kartockaDescription}>20 плит, 13.86м2, 0.278м3</p>
                                <p className={styles.kartockaPrice}>2 491 ₽/шт.</p>
                                <div className={styles.kartockaControls}>
                                    <button className={styles.kartockaBtn}>−</button>
                                    <input type="text" value="1"  className={styles.kartockaInput} />
                                    <button className={styles.kartockaBtn}>+</button>
                                    <button className={styles.kartockaCart}>Купить</button>
                                </div>
                            </div>
                        </div>

                        <div className={styles.kartocka}>
                            <div className={styles.kartockaImage}>
                                <img src="/img/teplo.webp" alt="" />
                            </div>
                            <div className={styles.kartockaContent}>
                                <p className={styles.kartockaName}>Пенопленекс Кофморт 1185x585x20мм</p>
                                <p className={styles.kartockaDescription}>20 плит, 13.86м2, 0.278м3</p>
                                <p className={styles.kartockaPrice}>3 200 ₽/шт.</p>
                                <div className={styles.kartockaControls}>
                                    <button className={styles.kartockaBtn}>−</button>
                                    <input type="text" value="1"  className={styles.kartockaInput} />
                                    <button className={styles.kartockaBtn}>+</button>
                                    <button className={styles.kartockaCart}>Купить</button>
                                </div>
                            </div>
                        </div>

                        <div className={styles.kartocka}>
                            <div className={styles.kartockaImage}>
                                <img src="/img/teplo.webp" alt="" />
                            </div>
                            <div className={styles.kartockaContent}>
                                <p className={styles.kartockaName}>Пенопленекс Кофморт 1185x585x20мм</p>
                                <p className={styles.kartockaDescription}>20 плит, 13.86м2, 0.278м3</p>
                                <p className={styles.kartockaPrice}>1 345 ₽/шт.</p>
                                <div className={styles.kartockaControls}>
                                    <button className={styles.kartockaBtn}>−</button>
                                    <input type="text" value="1"  className={styles.kartockaInput} />
                                    <button className={styles.kartockaBtn}>+</button>
                                    <button className={styles.kartockaCart}>Купить</button>
                                </div>
                            </div>
                        </div>

                        <div className={styles.kartocka}>
                            <div className={styles.kartockaImage}>
                                <img src="/img/teplo.webp" alt="" />
                            </div>
                            <div className={styles.kartockaContent}>
                                <p className={styles.kartockaName}>Пенопленекс Кофморт 1185x585x20мм</p>
                                <p className={styles.kartockaDescription}>20 плит, 13.86м2, 0.278м3</p>
                                <p className={styles.kartockaPrice}>2 600 ₽/шт.</p>
                                <div className={styles.kartockaControls}>
                                    <button className={styles.kartockaBtn}>−</button>
                                    <input type="text" value="1" className={styles.kartockaInput} />
                                    <button className={styles.kartockaBtn}>+</button>
                                    <button className={styles.kartockaCart}>Купить</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Kartocki2